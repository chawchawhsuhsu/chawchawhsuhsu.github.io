
from .models import UserProfile, Hobby, DesiredMatch, UserLike, UserMessage,UserMatch,AppUser,UserLogin
from django import forms
from django.contrib.auth import password_validation
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import AppUser


# Predefined Hobby Choices
HOBBIES_CHOICES = [
    ("reading", "Reading"), ("cooking", "Cooking"), ("travelling", "Travelling"),
    ("photographing", "Photographing"), ("meditation", "Meditation"),
    ("running", "Running"), ("swimming", "Swimming"), ("gym", "Gym"),
    ("cycling", "Cycling"), ("hiking", "Hiking"), ("doing_yoga", "Doing Yoga"),
    ("artist", "Artist"), ("music", "Music"), ("singing", "Singing"),
    ("acting", "Acting"), ("dancing", "Dancing"), ("coding", "Coding"),
    ("playing_games", "Playing Games"), ("watching_movies", "Watching Movies"),
    ("writing", "Writing"), ("sleeping", "Sleeping"), ("eating", "Eating"),
    ("camping", "Camping"), ("hacking", "Hacking"), ("playing_instruments", "Playing Instruments"),
    ("anime", "Anime"), ("language", "Language"), ("chess", "Chess"),
    ("tarot", "Tarot"), ("football", "Football"), ("basketball", "Basketball"),
    ("badminton", "Badminton")
]

# Predefined Gender Choices
GENDER_CHOICES = [
    ("male", "Male"),
    ("female", "Female"),
    ("other", "Other"),
]

# Predefined Zodiac Signs
ZODIAC_SIGNS = [
    ("aries", "Aries"), ("taurus", "Taurus"), ("gemini", "Gemini"),
    ("cancer", "Cancer"), ("leo", "Leo"), ("virgo", "Virgo"),
    ("libra", "Libra"), ("scorpio", "Scorpio"), ("sagittarius", "Sagittarius"),
    ("capricorn", "Capricorn"), ("aquarius", "Aquarius"), ("pisces", "Pisces"),
]


class UserRegisterForm(forms.ModelForm):
    username = forms.CharField(max_length=50,)
    email = forms.EmailField(required = True)
    password = forms.CharField(widget=forms.PasswordInput, required=True)
    confirmed_password = forms.CharField(widget=forms.PasswordInput, required=True)

    class Meta:
        model = AppUser
        fields = ['username', 'email', 'password', 'confirmed_password']



    # 🔹 Custom Validation for Unique Username
    def clean_username(self):
        username = self.cleaned_data.get("username")
        if AppUser.objects.filter(username=username).exists():
            raise ValidationError("This username is already taken. Please choose another.")
        if not re.match(r"^[a-zA-Z0-9_.-]+$", username):
            raise ValidationError("Username can only contain letters, numbers, dots, underscores, and hyphens.")
        return username

    def clean_confirmed_password(self):
        password = self.cleaned_data.get("password")
        confirmed_password = self.cleaned_data.get("confirmed_password")

        if password !=  confirmed_password:
            raise forms.ValidationError("Passwords do not match.")

        password_validation.validate_password(password)
        return  confirmed_password

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])  # Hash password
        if commit:
            user.save()
        return user


# User Login Form
class UserLoginForm(forms.ModelForm):
    username = forms.CharField(widget=forms.TextInput(attrs={"class": "form-control"}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={"class": "form-control"}))

    class Meta:
        model = UserLogin
        fields = ["username", "password"]

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not AppUser.objects.filter(username=username).exists():
            raise forms.ValidationError("Username does not exist.")
        return username





# User Profile Form (for creating/updating user profiles)
class UserProfileForm(forms.ModelForm):
    hobbies = forms.ModelMultipleChoiceField(
        queryset=Hobby.objects.all(),
        widget=forms.CheckboxSelectMultiple,  # Checkbox for hobbies
        required=False
    )

    class Meta:
        model = UserProfile
        fields = [
            'username','age', 'height', 'address', 'zodiac', 'hobbies', 'description',
            'occupation', 'contact_facebook', 'contact_email', 'contact_instagram', 'gender', 'profile_picture'
        ]

    def clean_hobbies(self):
        selected_hobbies = self.cleaned_data.get("hobbies")
        if selected_hobbies and len(selected_hobbies) > 5:
            raise ValidationError("You can select up to 5 hobbies only.")
        return selected_hobbies


from django import forms
from django.core.exceptions import ValidationError
from .models import DesiredMatch, Hobby

class DesiredMatchForm(forms.ModelForm):
    min_age = forms.IntegerField(
        required=False,
        min_value=18, max_value=45,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Min Age (Optional)'})
    )
    max_age = forms.IntegerField(
        required=False,
        min_value=18, max_value=45,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Max Age (Optional)'})
    )
    min_height = forms.IntegerField(
        required=False,
        min_value=50, max_value=250,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Min Height (Optional)'})
    )
    max_height = forms.IntegerField(
        required=False,
        min_value=50, max_value=250,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Max Height (Optional)'})
    )
    hobbies = forms.ModelMultipleChoiceField(
        queryset=Hobby.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )
    zodiac = forms.ChoiceField(
        choices=[('', 'Select Zodiac Sign')] + list(ZODIAC_SIGNS),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    gender = forms.ChoiceField(
        choices=[('', 'Select Gender')] + list(GENDER_CHOICES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = DesiredMatch
        fields = ['min_age', 'max_age', 'min_height', 'max_height', 'hobbies', 'zodiac', 'gender']

    def clean(self):
        cleaned_data = super().clean()
        min_age = cleaned_data.get("min_age")
        max_age = cleaned_data.get("max_age")
        min_height = cleaned_data.get("min_height")
        max_height = cleaned_data.get("max_height")



        # Ensure min_age is not greater than max_age
        if min_age and max_age and min_age > max_age:
            raise ValidationError("Minimum age cannot be greater than maximum age.")

        # Ensure min_height is not greater than max_height
        if min_height and max_height and min_height > max_height:
            raise ValidationError("Minimum height cannot be greater than maximum height.")



#User Profile

from django import forms
from django.core.exceptions import ValidationError
from .models import UserProfile, Hobby
import re

class UserInfoForm(forms.ModelForm):
    username = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your username'})
    )
    age = forms.IntegerField(
        required=False,
        min_value=18, max_value=45,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Age (18-45)'})
    )
    height = forms.IntegerField(
        required=False,
        min_value=50, max_value=250,
        widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Height in cm'})
    )
    address = forms.CharField(
        max_length=255,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your address'})
    )
    zodiac = forms.ChoiceField(
        choices=[('', 'Select your Zodiac Sign')] + list(ZODIAC_SIGNS),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    hobbies = forms.ModelMultipleChoiceField(
        queryset=Hobby.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple
    )
    description = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Tell us about yourself...', 'rows': 3}),
        required=False
    )
    occupation = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your occupation'})
    )
    contact_facebook = forms.CharField(
        max_length=50, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Facebook username (optional)'})
    )
    contact_email = forms.EmailField(
        max_length=50, required=False,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter your email'})
    )
    contact_instagram = forms.CharField(
        max_length=50, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Instagram username (optional)'})
    )
    gender = forms.ChoiceField(
        choices=[('', 'Select Gender')] + list(GENDER_CHOICES),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    profile_picture = forms.ImageField(
        required=False,
        widget=forms.FileInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = UserProfile
        fields = [
            'username', 'age', 'height', 'address', 'zodiac', 'hobbies', 'description',
            'occupation', 'contact_facebook', 'contact_email', 'contact_instagram', 'gender', 'profile_picture'
        ]


    # 🔹 Custom Validation for Unique Email
    def clean_contact_email(self):
        email = self.cleaned_data.get("contact_email")
        if email and UserProfile.objects.filter(contact_email=email).exists():
            raise ValidationError("This email is already in use.")
        return email

    # 🔹 Ensure at least one contact method is provided
    def clean(self):
        cleaned_data = super().clean()
        contact_facebook = cleaned_data.get("contact_facebook")
        contact_email = cleaned_data.get("contact_email")
        contact_instagram = cleaned_data.get("contact_instagram")

        if not contact_facebook and not contact_email and not contact_instagram:
            raise ValidationError("At least one contact method (Facebook, Email, or Instagram) must be provided.")

        return cleaned_data
#like user form
from django import forms
from .models import UserLike, AppUser

# Like Form for User to Like Another User (Ensures One-Time Like)
class LikeForm(forms.ModelForm):
    to_user = forms.ModelChoiceField(queryset=AppUser.objects.all(), widget=forms.HiddenInput())

    class Meta:
        model = UserLike
        fields = ['to_user']

    def save(self, from_user, commit=True):
        """Custom save method to handle 'from_user' and prevent multiple likes."""
        # Ensure a user can only like another user once
        user_like, created = UserLike.objects.get_or_create(
            from_user=from_user, to_user=self.cleaned_data['to_user']
        )

        if not created:
            raise forms.ValidationError("You have already liked this user.")

        # Check for a match (when both users like each other)
        if UserLike.objects.filter(from_user=user_like.to_user, to_user=from_user).exists():
            user_like.matched = True
            user_like.save()

        return user_like



#user browse
from django import forms
from .models import UserProfile

class UserBrowseForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = [
            'username', 'age', 'height', 'address', 'zodiac', 'hobbies', 'description',
            'occupation', 'contact_facebook', 'contact_email', 'contact_instagram', 'gender', 'profile_picture'
        ]  # Fields to display only


from django import forms
from .models import AppUser,UserProfile # Import the user model


from django import forms
from .models import AppUser,UserProfile # Import the user model


class LikesReceivedForm(forms.Form):
    """Form to filter and display users who liked the logged-in user."""
    users = forms.ModelMultipleChoiceField(
        queryset=AppUser.objects.none(),  # Will be set dynamically in the view
        widget=forms.CheckboxSelectMultiple,
        required=False
    )


    def init(self, *args, **kwargs):
        user = kwargs.pop("user", None)  # Get logged-in user
        super().init(*args, **kwargs)

        if user:
            self.fields['users'].queryset = AppUser.objects.filter(liked__to_user=user)

# Message Form (For Chat Between Matched Users)


from django import forms
from .models import UserMessage

class MessageForm(forms.ModelForm):
    class Meta:
        model = UserMessage
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'placeholder': 'Type your message here...', 'rows': 3})
        }


from django import forms

from .models import Review  # Add this line if it's missing


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['content', 'rating']
        widgets = {
            'content': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Write your review...'}),
            'rating': forms.Select(attrs={'class': 'form-control'}, choices=[(i, str(i)) for i in range(1, 6)])
        }
class UnmatchForm(forms.Form):
    confirm = forms.BooleanField(required=True, label="Are you sure you want to unmatch?")

# account deletion
from django import forms

class AccountDeletionForm(forms.Form):
    reason = forms.CharField(widget=forms.Textarea(attrs={'rows': 4, 'placeholder': 'Please provide a reason for deleting your account...'}))