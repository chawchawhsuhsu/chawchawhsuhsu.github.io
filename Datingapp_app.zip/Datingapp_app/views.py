from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import (
    UserRegisterForm, UserLoginForm, UserProfileForm, DesiredMatchForm,
    LikeForm, MessageForm, UserInfoForm, UserBrowseForm
)
from .models import UserProfile, UserLike, UserMatch, UserMessage, DesiredMatch, AppUser
from django.db.models import Q

def home(request):
    return render(request, "home.html")

def home1(request):
    return render(request, "home1.html")
def information(request, username):
    # Correct usage of get_object_or_404
    user = get_object_or_404(UserProfile, username=username)
    if user.user== request.user:
        return redirect("user_profile")
    return render(request, 'information.html', {'user': user})

#@login_required
#def user_profile(request, user_id):
    # ကိုယ့် profile မပါအောင် filter လုပ်မယ်
    #profile = get_object_or_404(UserProfile, id=user_id)
    # ကိုယ့် profile ဆိုရင် home page redirect
    #if profile.user == request.user:
       # return redirect("browse_profiles")
    #return render(request, "user_profile.html", {"user": profile.user})



# 🟢 User Registration
def register(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect("home1")  # Redirect to profile edit page
    else:
        form = UserRegisterForm()
    return render(request, "register.html", {"form": form})


def user_login(request):
    if request.method == "POST":
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Admin login check
            if username == "admin" and password == "admin":
                # Authenticate and login the admin user
                admin_user = authenticate(request, username=username, password=password)
                if admin_user:
                    login(request, admin_user)
                    messages.success(request, "Your login is successful.")
                    return redirect('admin_dashboard')
                else:
                    messages.error(request, "Failed to login .")

            # Regular user login check
            else:
                # Authenticate regular user based on the AppUser model
                user = authenticate(request, username=username, password=password)
                if user is not None:
                    login(request, user)
                    messages.success(request, "Login successful.")
                    return redirect('browse_profiles')  # Redirect to user's dashboard
                else:
                    messages.error(request, "Invalid credentials")

    else:
        form = UserLoginForm()

    return render(request, "login.html", {"form": form})

def admin_dashboard(request):
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect if not authenticated

    # Get all registered users and matched couples
    users = AppUser.objects.all()
    matched_couples = UserMatch.objects.all()  # Assuming 'Match' is a model for couples

    return render(request, 'admin_dashboard.html', {
        'users': users,
        'matched_couples': matched_couples
    })



# 🟢 User Logout
# 🟢 User Logout
@login_required
def user_logout(request):
    if request.method == "POST":
        action = request.POST.get("action")

        if action == "temporary":
            logout(request)
            return redirect("home")  # Redirect to login page

        elif action == "permanent":
            # Instead of modifying models, mark the user as inactive
            user = request.user
            user.is_active = False
            user.save()

            # Notify admin (optional: you can log this or send an email)
            messages.info(request, "Your account deactivation request has been sent to the admin.")
            logout(request)
            return redirect("home")  # Redirect to confirmation page

    return render(request, "logout_options.html")


# 🟢 Edit or Create Profile
@login_required
def edit_profile(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect("dashboard")
    else:
        form = UserProfileForm(instance=user_profile)
    return render(request, "edit_profile.html", {"form": form})

# 🟢 Set Desired Match Preferences
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import DesiredMatch
from .forms import DesiredMatchForm

@login_required
def set_preferences(request):
    desired_match, created = DesiredMatch.objects.get_or_create(user=request.user)

    if request.method == "POST":
        form = DesiredMatchForm(request.POST, instance=desired_match)
        if form.is_valid():
            preferences = form.save(commit=False)
            preferences.user = request.user  # Ensure user is set
            preferences.save()
            messages.success(request, "Preferences saved successfully!")
            return redirect("your_recommendations")  # Redirect to dashboard after saving
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = DesiredMatchForm(instance=desired_match)

    return render(request, "preferences.html", {"form": form})


@login_required
def show_matches(request):
    """ View to show users matching the logged-in user's preferences. """
    try:
        preferences = DesiredMatch.objects.get(user=request.user)
    except DesiredMatch.DoesNotExist:
        messages.warning(request, "Please set your preferences first.")
        return redirect("your_recommendations")

    # Filter users based on preferences
    potential_matches = UserProfile.objects.exclude(user=request.user)

    if preferences.min_age:
        potential_matches = potential_matches.filter(age__gte=preferences.min_age)
    if preferences.max_age:
        potential_matches = potential_matches.filter(age__lte=preferences.max_age)
    if preferences.min_height:
        potential_matches = potential_matches.filter(height__gte=preferences.min_height)
    if preferences.max_height:
        potential_matches = potential_matches.filter(height__lte=preferences.max_height)
    if preferences.gender:
        potential_matches = potential_matches.filter(gender=preferences.gender)
    if preferences.zodiac:
        potential_matches = potential_matches.filter(zodiac=preferences.zodiac)
    if preferences.hobbies.exists():
        hobby_filter = Q()
        for hobby in preferences.hobbies.all():
            hobby_filter |= Q(hobbies=hobby)  # Match at least one hobby

        potential_matches = potential_matches.filter(hobby_filter).prefetch_related("hobbies").distinct()

    return render(request, "your_recommendations.html", {"matches": potential_matches})


from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import LikeForm
from .models import AppUser
from django import forms

def like_user(request, user_id):
    """Handle liking a user and checking for a match."""
    liked_user = get_object_or_404(AppUser, id=user_id)  # Get the user being liked

    if request.method == "POST":
        form = LikeForm(request.POST)
        if form.is_valid():
            # ✅ Pass 'from_user' when calling save()
            try:
                user_like = form.save(from_user=request.user)  # 'request.user' is the logged-in user

                messages.success(request, f"You liked {liked_user.username}!")

                # ✅ Check if a match occurs
                if user_like.matched:
                    messages.success(request, f"You matched with {liked_user.username}! You can now message each other.")

                return redirect('browse_profiles')  # Redirect to browse profiles page
            except forms.ValidationError as e:
                messages.error(request, str(e))  # Handle the case where the user has already liked the other user
    else:
        form = LikeForm(initial={'to_user': liked_user})

    return render(request, 'like.html', {
        'form': form,
        'liked_user': liked_user
    })

# 🟢 Show All Users(browse)
# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import UserProfile, UserLike
from .forms import LikeForm
from django.contrib.auth.decorators import login_required

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import UserProfile, UserLike
from .forms import LikeForm
from django.contrib.auth.decorators import login_required

@login_required
def browse_profiles(request):
    # Exclude the logged-in user from the list
    users = UserProfile.objects.exclude(user=request.user)

    if request.method == "POST":
        form = LikeForm(request.POST)
        if form.is_valid():
            liked_user = form.cleaned_data['to_user']
            user_like = form.save(from_user=request.user)

            # ✅ Flash messages for successful like
            messages.success(request, f"You liked {liked_user.username}!")
            messages.info(request, f"{liked_user.username} has been notified.")

            # ✅ Check for a match
            if user_like.matched:
                messages.success(request, f"You matched with {liked_user.username}! You can now message each other.")

            return redirect('browse_profiles')  # Redirect to refresh the page

    else:
        form = LikeForm()  # Empty form when just browsing

    return render(request, 'browse_profiles.html', {
        'users': users,
        'form': form
    })

#
# 🟢 List Matches (Users who have liked each other)
@login_required
def my_matches(request):
    matches = UserMatch.objects.filter(Q(user1=request.user) | Q(user2=request.user))
    return render(request, "matches.html", {"matches": matches})

        # 🟢 Match Recommendation System (Shows potential matches)
@login_required
def recommended_matches(request):
    user_preferences = DesiredMatch.objects.filter(user=request.user).first()
    if not user_preferences:
        messages.warning(request, "Please set your preferences first.")
        return redirect("preferences")

    # Filtering logic
    potential_matches = UserProfile.objects.exclude(user=request.user)
    filtered_matches = potential_matches.filter(
        age__gte=user_preferences.min_age,
        age__lte=user_preferences.max_age,
        height__gte=user_preferences.min_height,
        height__lte=user_preferences.max_height,
        gender=user_preferences.gender
    )

    # Check if hobbies and zodiac match at least 3 out of 5 criteria
    best_matches = []
    for profile in filtered_matches:
        match_count = 0
        if profile.zodiac == user_preferences.zodiac:
            match_count += 1
        if profile.hobbies.filter(id__in=user_preferences.hobbies.values_list("id", flat=True)).count() >= 3:
            match_count += 1
        if match_count >= 3:
            best_matches.append(profile)

    return render(request, "recommended_matches.html", {"matches": best_matches})


# 🟢 Dashboard(don't touch)
@login_required
def dashboard(request):
    profile = UserProfile.objects.get(user=request.user)

    # Get profile of logged-in user

    """User dashboard where they can see if someone liked them."""
    liked_notification = request.session.pop("liked_notification", None)
    match_notification = request.session.pop("match_notification", None)

    if liked_notification:
        messages.info(request, liked_notification)

    if match_notification:
        messages.success(request, match_notification)



    return render(request, 'dashboard.html', {'profile': profile})

#User Profile
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib import messages
from .forms import UserRegisterForm
from .models import UserProfile
from .forms import UserInfoForm

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import login
from .forms import UserInfoForm
from .models import UserProfile


def UserInfo(request):
    hobbies = None  # Initialize hobbies to avoid errors in GET requests


    if request.method == "POST":
        form = UserInfoForm(request.POST, request.FILES)
        if form.is_valid():
            user_profile = form.save(commit=False)  # Prevent immediate save
            user_profile.user = request.user  # Assign logged-in user
            user_profile.save()  # Save UserProfile
            form.save_m2m()  # Save ManyToMany fields (hobbies)

            login(request, user_profile.user)  # Log in the user
            messages.success(request, "Profile created successfully! Welcome to SoulSync.")
            return redirect("browse_profiles")  # Redirect to dashboard
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = UserInfoForm()

    return render(request, "userinfo.html", {"form": form, "hobbies": hobbies})


#like_received

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import UserLike, UserProfile
from .forms import LikesReceivedForm


@login_required
def likes_received(request):
    """View to display users who liked the logged-in user."""
    # Get users who liked the logged-in user
    liked_by_users = AppUser.objects.filter(liker__to_user=request.user)

    # Render the list of users who liked the logged-in user
    return render(request, 'likes_received.html', {
        'liked_by_users': liked_by_users,
    })

'''from django.shortcuts import render, get_object_or_404
from .models import UserProfile

def user_profile(request, username):
    # Correct usage of get_object_or_404
    user = get_object_or_404(UserProfile, username=username)

    return render(request, 'user_profile.html', {'user': user})'''
from django.shortcuts import render, get_object_or_404
from .models import UserProfile

@login_required

def user_profile(request, username):
    # Correct usage of get_object_or_404
    user = get_object_or_404(UserProfile, username=username)
    return render(request, 'user_profile.html', {'user': user})





 #🟢 Message a Matched User

# views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import UserMatch, UserMessage, AppUser
from .forms import MessageForm
from django.http import JsonResponse


# Chat view (for matched users)
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from .models import UserMessage, AppUser, UserMatch
from .forms import MessageForm
from django.contrib.auth.decorators import login_required

@login_required
def chat_view(request, receiver_id):
    # Get the receiver based on receiver_id
    receiver = get_object_or_404(AppUser, id=receiver_id)

    # Check if there's a match between the logged-in user and the receiver
    if not UserMatch.objects.filter(
        Q(user1=request.user, user2=receiver) | Q(user1=receiver, user2=request.user)
    ).exists():
        return redirect('dashboard')  # Redirect if no match exists

    # Get existing messages between the two matched users, ordered by ID (acts like a timestamp)
    messages = UserMessage.objects.filter(
        (Q(sender=request.user) & Q(receiver=receiver)) |
        (Q(sender=receiver) & Q(receiver=request.user))
    ).order_by("id")  # Ordering by message ID

    # Handle message sending (POST request)
    if request.method == "POST":
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = receiver
            message.save()

            return redirect('chat_view', receiver_id=receiver.id)
    else:
        form = MessageForm()

    return render(request, 'chat_view.html', {
        'receiver': receiver,
        'messages': messages,
        'form': form
    })
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import UserMessage, AppUser

@login_required
def send_message(request):
    if request.method == 'POST':
        receiver_id = request.POST.get('receiver_id')
        text = request.POST.get('text')

        if not receiver_id or not text:
            return JsonResponse({'error': 'Missing receiver or text'}, status=400)

        # Fetch the receiver user object
        try:
            receiver = AppUser.objects.get(id=receiver_id)
        except AppUser.DoesNotExist:
            return JsonResponse({'error': 'Receiver not found'}, status=404)

        # Create and save the message
        message = UserMessage.objects.create(
            sender=request.user,
            receiver=receiver,
            text=text
        )

        # Return message details as a JSON response
        return JsonResponse({
            'message': message.text,
            'sender': message.sender.username,
            'message_id': message.id  # Using message ID for ordering instead of timestamp
        })
    return JsonResponse({'error': 'Invalid request'}, status=400)


from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from .models import UserMatch, UserLike, AppUser
from django.db.models import Q

def unmatch_users(request, user_id):
    current_user = request.user
    other_user = get_object_or_404(AppUser, id=user_id)

    # Delete the match
    UserMatch.objects.filter(
        Q(user1=current_user, user2=other_user) | Q(user1=other_user, user2=current_user)
    ).delete()

    # Also update UserLike to remove 'matched' status
    UserLike.objects.filter(
        Q(from_user=current_user, to_user=other_user) | Q(from_user=other_user, to_user=current_user)
    ).update(matched=False)

    messages.success(request, "You have successfully unmatched.")
    return redirect("my_matches")  # Redirect to the match list page

#account deletion request
from django.shortcuts import render, redirect
from django.contrib.auth import logout
from .forms import AccountDeletionForm

def account_deletion_requested(request):
    """Handles account deletion requests with a reason."""
    if request.method == "POST":
        form = AccountDeletionForm(request.POST)
        if form.is_valid():
            # Deactivate user account
            user = request.user
            user.is_active = False
            user.save()

            # Save the reason for deletion (store in the user model or create a separate model if required)
            reason = form.cleaned_data['reason']
            # You could save this reason in a custom model or a log here if necessary.

            # Log out the user
            logout(request)

            # Redirect to a confirmation page (or display the success message here)
            return redirect('account_deletion_requested')

    else:
        form = AccountDeletionForm()

    return render(request, "account_deletion_requested.html", {"form": form})

#admin dashboard
from django.shortcuts import render
from django.contrib.auth.models import User
from .models import UserMatch

def admin_dashboard(request):
    # Fetch all users and matched couples
    users = AppUser.objects.all()
    matched_couples = UserMatch.objects.all()
    deactivated_users = AppUser.objects.filter(is_active=False)  # Fetch users who requested deletion
    unmatched_couples = UserMatch.objects.filter(user1__is_active=True, user2__is_active=True)

    return render(request, 'admin_dashboard.html', {
        'users': users,
        'matched_couples': matched_couples,
        'deactivated_users': deactivated_users,
        'unmatched_couples': unmatched_couples,
    })

def matched_couples(request):
    # Fetch all users and matched couples
    matched_couples = UserMatch.objects.all()
    return render(request, 'matched_couples.html', {
        'matched_couples': matched_couples,
    })
def deactivate_users(request):
    # Fetch all users and matched couples
    deactivate_users = AppUser.objects.filter(is_active=False)
    return render(request, 'deactivate_users.html', {
        'deactivated_users': deactivate_users,
    })




#approve deletion
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages

from django.shortcuts import render, redirect
from soulsync.models import AppUser  # Replace with your actual AppUser import
from django.contrib import messages


def approve_deletion(request, user_id):
    """Approve account deletion requested by the user."""
    user = AppUser.objects.get(id=user_id)  # Use AppUser instead of User

    if user.is_active == False:  # Make sure the user has requested deactivation
        user.delete()  # Permanently delete the user
        messages.success(request, f"User {user.username} has been deleted successfully.")
    else:
        messages.error(request, "User has not requested deletion.")

    return redirect('admin_dashboard')



from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Review
from .forms import ReviewForm

def reviews_page(request):
    reviews = Review.objects.all().order_by('-timestamp')
    return render(request, 'reviews.html', {'reviews': reviews, 'user_authenticated': request.user.is_authenticated})

@login_required
def submit_review(request):
    reviews= Review.objects.all().order_by('-timestamp')
    if request.method == "POST":
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.user = request.user
            review.save()
            return redirect('browse_profiles')
    else:
        form = ReviewForm()
    return render(request, 'submit_review.html', {'form': form, 'reviews':reviews})


@login_required
def admin_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("home")