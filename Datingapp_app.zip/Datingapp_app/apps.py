from django.apps import AppConfig


class SoulsyncConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'soulsync'
