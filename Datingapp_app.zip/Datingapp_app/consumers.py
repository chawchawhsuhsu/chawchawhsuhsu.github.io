# consumers.py
import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import UserMessage, AppUser


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        self.receiver_id = self.scope['url_route']['kwargs']['receiver_id']
        self.receiver = await database_sync_to_async(AppUser.objects.get)(id=self.receiver.user_id)

        # Create a unique group for each pair of users
        self.chat_group_name = f"chat_{min(self.user.user_id, self.receiver_id)}_{max(self.user.user_id, self.receiver_id)}"

        # Join the group
        await self.channel_layer.group_add(
            self.chat_group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        # Leave the group when the user disconnects
        await self.channel_layer.group_discard(
            self.chat_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message = text_data_json['message']

        # Save the message to the database
        await self.save_message(self.user, self.receiver, message)

        # Send the message to the group (both users)
        await self.channel_layer.group_send(
            self.chat_group_name,
            {
                'type': 'chat_message',
                'sender': self.user.username,
                'message': message
            }
        )

    async def chat_message(self, event):
        sender = event['sender']
        message = event['message']

        # Send the message to WebSocket
        await self.send(text_data=json.dumps({
            'sender': sender,
            'message': message
        }))

    @database_sync_to_async
    def save_message(self, sender, receiver, text):
        UserMessage.objects.create(sender=sender, receiver=receiver, text=text)
