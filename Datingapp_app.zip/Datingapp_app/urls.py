from django.urls import path
from django.contrib.auth import views as auth_views
from .import views

from django.urls import path
from . import views
from django.urls import path
from .views import register



urlpatterns = [
  path('',views.home,name='home'),
  path('home1/', views.home1, name='home1'),
  path('information/', views.information, name='information'),
  path('profiles/<str:username>/', views.user_profile, name='user_profile'),

  path('reviews/', views.reviews_page, name='reviews'),
  path('submit_review/', views.submit_review, name='submit_review'),

  # User Registration and Login URLs
  path('register/', views.register, name='register'),
  path('login/', views.user_login, name='login'),
  path('user_logout/', views.user_logout, name='user_logout'),
  path('admin_logout/', views.admin_logout, name='admin_logout'),

  # Profile and Preferences URLs
  path('edit_profile/', views.edit_profile, name='edit_profile'),
  path('preferences/', views.set_preferences, name='preferences'),



  # User Interaction (Browse, Like, Matches, etc.)
  path('browse_profiles/', views.browse_profiles, name='browse_profiles'),
  path('like/<int:user_id>/', views.like_user, name='like'),
  path('my_matches/', views.my_matches, name='my_matches'),
  path('chat/<int:receiver_id>/', views.chat_view, name='chat_view'),
  path('send_message/', views.send_message, name='send_message'),  # Optional if using AJAX
#  Match Recommendation and Dashboard URLs
  path('recommended_matches/', views.recommended_matches, name='recommended_matches'),
  path('dashboard/', views.dashboard, name='dashboard'),
 # path('user/<str:username>/', views.user_profile, name='user_profile'),
  path("userinfo/", views.UserInfo, name="userinfo"),
  path("your_recommendations/", views.show_matches, name="your_recommendations"),
  path('likes-received/', views.likes_received, name='likes_received'),

path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
path('approve_deletion/<int:user_id>/', views.approve_deletion, name='approve_deletion'),
path('unmatch/<int:user_id>/', views.unmatch_users, name='unmatch'),
path('matched_couples/', views.matched_couples, name='matched_couples'),
path( 'deactivate_users/',views.deactivate_users, name='deactivate_users'),
]



