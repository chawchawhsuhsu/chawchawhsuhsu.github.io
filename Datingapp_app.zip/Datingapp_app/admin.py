from django.contrib import admin
from .models import AppUser, Hobby, UserLike, UserMatch, UserMessage, UserProfile, DesiredMatch, UserLogin, Review
from .models import AppUser, UserMatch
# Register your models here.
admin.site.register(AppUser)
admin.site.register(Hobby)
admin.site.register(UserLike)
admin.site.register(UserMatch)
admin.site.register(UserProfile)
admin.site.register(UserMessage)
admin.site.register(DesiredMatch)
admin.site.register(UserLogin)
admin.site.register(Review)

# Registering AppUser (your custom user model) to the admin

class AppUserAdmin(admin.ModelAdmin):
    list_display = ("username", "email", "is_active")
    actions = ["approve_account_deletion"]

    def approve_account_deletion(self, request, queryset):
        for user in queryset:
            if not user.is_active:  # Only delete users who requested deactivation
                user.delete()
        self.message_user(request, "Selected users have been deleted.")

    approve_account_deletion.short_description = "Approve and Delete Deactivated Accounts"
