from django.contrib.auth.models import AbstractUser
from django.db import models
from django.contrib.auth.hashers import make_password

# Predefined Hobby Choices
HOBBIES_CHOICES = [
    ("reading", "Reading"), ("cooking", "Cooking"), ("travelling", "Travelling"),
    ("photographing", "Photographing"), ("meditation", "Meditation"),
    ("running", "Running"), ("swimming", "Swimming"), ("gym", "Gym"),
    ("cycling", "Cycling"), ("hiking", "Hiking"), ("doing_yoga", "Doing Yoga"),
    ("artist", "Artist"), ("music", "Music"), ("singing", "Singing"),
    ("acting", "Acting"), ("dancing", "Dancing"), ("coding", "Coding"),
    ("playing_games", "Playing Games"), ("watching_movies", "Watching Movies"),
    ("writing", "Writing"), ("sleeping", "Sleeping"), ("eating", "Eating"),
    ("camping", "Camping"), ("hacking", "Hacking"), ("playing_instruments", "Playing Instruments"),
    ("anime", "Anime"), ("language", "Language"), ("chess", "Chess"),
    ("tarot", "Tarot"), ("football", "Football"), ("basketball", "Basketball"),
    ("badminton", "Badminton")
]

# Predefined Gender Choices
GENDER_CHOICES = [
    ("male", "Male"),
    ("female", "Female"),
    ("other", "Other"),
]

# Predefined Zodiac Signs
ZODIAC_SIGNS = [
    ("aries", "Aries"), ("taurus", "Taurus"), ("gemini", "Gemini"),
    ("cancer", "Cancer"), ("leo", "Leo"), ("virgo", "Virgo"),
    ("libra", "Libra"), ("scorpio", "Scorpio"), ("sagittarius", "Sagittarius"),
    ("capricorn", "Capricorn"), ("aquarius", "Aquarius"), ("pisces", "Pisces"),
]

# Hobby Model
class Hobby(models.Model):
    name = models.CharField(max_length=50, choices=HOBBIES_CHOICES, unique=True)

    def __str__(self):
        return self.get_name_display()

class AppUser(AbstractUser):
    username = models.CharField(max_length=50, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=50)
    confirmed_password = models.CharField(max_length=50)

    def __str__(self):
        return self.username



class UserLogin(models.Model):
    user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=128)

    def __str__(self):
        return self.username


# User Profile Model
class UserProfile(models.Model):
    user = models.OneToOneField(AppUser, on_delete=models.CASCADE, related_name="profile")
    username = models.CharField(max_length=50, unique=True)

    age = models.IntegerField(blank = True,null = True)
    height = models.IntegerField(blank = True,null = True)
    address = models.CharField(max_length=255)
    zodiac = models.CharField(max_length=20, choices=ZODIAC_SIGNS)
    hobbies = models.ManyToManyField(Hobby, blank=True)
    description = models.TextField(max_length=100, blank=True)
    occupation = models.CharField(max_length=100)
    contact_facebook = models.CharField(blank=True, max_length=50)
    contact_email = models.EmailField(blank=True, max_length=50)
    contact_instagram = models.CharField(blank=True, max_length=50)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    profile_picture = models.ImageField(upload_to="static/profile_pics/", default="default.jpg")

    def __str__(self):
        return self.username


# Like Model (Tracks user likes)
class UserLike(models.Model):
    from_user = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="liker")
    to_user = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="liked")
    matched = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        """Check if a match occurs when saving a like."""
        if UserLike.objects.filter(from_user=self.to_user, to_user=self.from_user).exists():
            self.matched = True
            super().save(*args, **kwargs)
            UserMatch.objects.create(user1=self.from_user, user2=self.to_user)
        else:
            super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.from_user.username} likes {self.to_user.username}"


# Match Model (Confirmed Matches)
class UserMatch(models.Model):
    user1 = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="match1")
    user2 = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="match2")

    def __str__(self):
        return f"{self.user1.username} & {self.user2.username}"


# Desired Match Model (User Preferences)
class DesiredMatch(models.Model):
    user = models.OneToOneField(AppUser, on_delete=models.CASCADE, related_name="desired_match")
    min_age = models.IntegerField(blank = True,null = True)
    max_age = models.IntegerField(blank = True,null = True)
    min_height = models.IntegerField(blank = True,null = True)
    max_height = models.IntegerField(blank = True,null = True)
    hobbies = models.ManyToManyField(Hobby, blank=True)
    zodiac = models.CharField(max_length=20, choices=ZODIAC_SIGNS, blank=True, null=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True, null=True)

    def __str__(self):
        return f"{self.user.username}'s Preferences"


# Message Model (For Chat Between Matched Users)
class UserMessage(models.Model):
    sender = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey(AppUser, on_delete=models.CASCADE, related_name="received_messages")
    text = models.TextField()

    def __str__(self):
        return f"{self.sender.username} -> {self.receiver.username}: {self.text[:30]}"




from django.db import models
from django.contrib.auth.models import User
from django.utils.timezone import now

class Review(models.Model):
    user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
    content = models.TextField()
    rating = models.IntegerField(choices=[(i, str(i)) for i in range(1, 6)], default=5)
    timestamp = models.DateTimeField(default=now)

    def str(self):
        return f"{self.user.username} - {self.timestamp.strftime('%Y-%m-%d %H:%M')} - {self.rating} Stars"