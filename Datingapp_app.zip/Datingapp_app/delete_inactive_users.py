from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import LikeForm
from .models import AppUser
from django import forms

def like_user(request, user_id):
    """Handle liking a user and checking for a match."""
    liked_user = get_object_or_404(AppUser, id=user_id)  # Get the user being liked

    if request.method == "POST":
        form = LikeForm(request.POST)
        if form.is_valid():
            # ✅ Pass 'from_user' when calling save()
            try:
                user_like = form.save(from_user=request.user)  # 'request.user' is the logged-in user

                messages.success(request, f"You liked {liked_user.username}!")

                # ✅ Check if a match occurs
                if user_like.matched:
                    messages.success(request, f"You matched with {liked_user.username}! You can now message each other.")

                return redirect('browse_profiles')  # Redirect to browse profiles page
            except forms.ValidationError as e:
                messages.error(request, str(e))  # Handle the case where the user has already liked the other user
    else:
        form = LikeForm(initial={'to_user': liked_user})

    return render(request, 'like.html', {
        'form': form,
        'liked_user': liked_user
    })